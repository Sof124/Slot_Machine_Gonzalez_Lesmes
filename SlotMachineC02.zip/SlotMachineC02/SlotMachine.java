import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import javax.swing.JOptionPane;

/**
 * Simula una máquina tragamonedas compuesta por un número variable de
 * ruedas. Esta clase solo conoce a {@link Wheel} (nunca a {@code Symbol}) y
 * las figuras necesarias para su propio cuerpo fijo (marco, base y
 * palanca). Se encarga de las reglas del juego —agregar/quitar/intercambiar
 * ruedas, fijar/soltar ruedas, girar, determinar el jackpot— y de calcular
 * la distribución horizontal de las ruedas dentro de su cuerpo.
 *
 * @author GonzalezM-LesmesA
 * @version 1.5
 */
public class SlotMachine {

    /** Pausa (ms) entre cada paso al girar una rueda de forma animada. */
    private static final int SPIN_STEP_DELAY_MS = 150;

    private List<Wheel> wheels;
    private boolean isVisible;
    private boolean lastOperationOk;
    private final Random random;

    // Componentes visuales fijos del cuerpo de la máquina
    private Rectangle frame;
    private Rectangle base;
    private Rectangle leverArm;
    private Circle leverBall;

    /**
     * Inicializa la máquina tragamonedas con la configuración por defecto:
     * tres ruedas, cada una con un símbolo.
     */
    public SlotMachine() {
        this.wheels = new ArrayList<>();
        this.isVisible = false;
        this.lastOperationOk = true;
        this.random = new Random();
        initStructure();
        initDefaultConfiguration();
    }

    /**
     * Adiciona una rueda vacía en la posición especificada. Si la posición es
     * menor a 1 se usa 1; si es mayor al máximo posible se usa el máximo.
     *
     * @param pos Posición basada en 1
     */
    public void addWheel(int pos) {
        int index = clampInsertPosition(pos, wheels.size());
        wheels.add(index, new Wheel());
        lastOperationOk = true;
        refreshDisplay();
    }

    /**
     * Elimina la rueda ubicada en la posición dada. Si no hay ruedas la
     * operación falla; en otro caso la posición se ajusta a los límites válidos.
     *
     * @param pos Posición basada en 1
     */
    public void delWheel(int pos) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas para eliminar.");
            return;
        }
        int index = clampWheelNumber(pos);
        wheels.get(index - 1).hide();
        wheels.remove(index - 1);
        lastOperationOk = true;
        refreshDisplay();
    }

    /**
     * Intercambia la posición de dos ruedas dentro de la máquina. El estado
     * de cada rueda (símbolos, posición visible, fija o libre) viaja con
     * ella al intercambiarse.
     *
     * @param wheel1 Número de la primera rueda, basado en 1
     * @param wheel2 Número de la segunda rueda, basado en 1
     */
    public void swap(int wheel1, int wheel2) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas para intercambiar.");
            return;
        }
        int index1 = clampWheelNumber(wheel1);
        int index2 = clampWheelNumber(wheel2);
        Wheel temp = wheels.get(index1 - 1);
        wheels.set(index1 - 1, wheels.get(index2 - 1));
        wheels.set(index2 - 1, temp);
        lastOperationOk = true;
        refreshDisplay();
    }

    /**
     * Fija (bloquea) una rueda para que no gire cuando se invoque {@link #spin()}.
     *
     * @param wheel Número de rueda, basado en 1
     */
    public void lock(int wheel) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas para fijar.");
            return;
        }
        int index = clampWheelNumber(wheel);
        lastOperationOk = wheels.get(index - 1).lock();
        if (!lastOperationOk) {
            handleError("La rueda ya estaba fija.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Suelta (desbloquea) una rueda previamente fijada.
     *
     * @param wheel Número de rueda, basado en 1
     */
    public void unlock(int wheel) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas para soltar.");
            return;
        }
        int index = clampWheelNumber(wheel);
        lastOperationOk = wheels.get(index - 1).unlock();
        if (!lastOperationOk) {
            handleError("La rueda ya estaba libre.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Adiciona un símbolo por color a todas las ruedas, en la posición
     * especificada dentro de cada una. La validez del color la determina
     * cada rueda; esta clase no conoce el concepto de símbolo.
     *
     * @param pos   Posición dentro de la rueda, basada en 1
     * @param color Nombre del color CSS del símbolo
     */
    public void addSymbol(int pos, String color) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas para adicionar símbolos.");
            return;
        }
        boolean allOk = true;
        for (Wheel w : wheels) {
            allOk = w.addSymbol(pos, color) && allOk;
        }
        lastOperationOk = allOk;
        if (!lastOperationOk) {
            handleError("El color '" + color + "' no es un color CSS válido.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Elimina la primera ocurrencia del símbolo según su color, en todas las ruedas.
     *
     * @param symbol Color del símbolo a eliminar
     */
    public void delSymbol(String symbol) {
        boolean removedAny = false;
        for (Wheel w : wheels) {
            if (w.delSymbol(symbol)) {
                removedAny = true;
            }
        }
        lastOperationOk = removedAny;
        if (!lastOperationOk) {
            handleError("Símbolo no encontrado.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Ubica en la ventana visible de una rueda el símbolo del color especificado.
     *
     * @param wheel  Número de rueda, basado en 1
     * @param symbol Color del símbolo a ubicar
     */
    public void placeSymbol(int wheel, String symbol) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas disponibles.");
            return;
        }
        int index = clampWheelNumber(wheel);
        lastOperationOk = wheels.get(index - 1).placeSymbol(symbol);
        if (!lastOperationOk) {
            handleError("Símbolo no encontrado en la rueda.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Gira un paso hacia adelante la rueda especificada. No hace nada (y
     * reporta error) si la rueda está fija.
     *
     * @param wheel Número de rueda, basado en 1
     */
    public void spin(int wheel) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas disponibles.");
            return;
        }
        int index = clampWheelNumber(wheel);
        lastOperationOk = wheels.get(index - 1).spin();
        if (!lastOperationOk) {
            handleError("La rueda está fija o vacía; no puede girar.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Gira la rueda especificada el número de pasos indicado. Si el
     * simulador está visible, el movimiento se visualiza paso a paso.
     *
     * @param wheel Número de rueda, basado en 1
     * @param steps Número de pasos a girar, debe ser mayor a cero
     */
    public void spin(int wheel, int steps) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas disponibles.");
            return;
        }
        if (steps < 1) {
            handleError("El número de pasos debe ser mayor a cero.");
            return;
        }
        int index = clampWheelNumber(wheel);
        Wheel w = wheels.get(index - 1);
        if (w.isLocked()) {
            handleError("La rueda está fija; no puede girar.");
            return;
        }
        for (int i = 0; i < steps; i++) {
            w.spin();
            if (isVisible) {
                refreshDisplay();
                pause();
            }
        }
        lastOperationOk = true;
        refreshDisplay();
    }

    /**
     * Tira de la palanca: hace girar todas las ruedas no fijas de la
     * máquina, cada una una cantidad de pasos aleatoria e independiente de
     * las demás. Es justamente esta independencia entre ruedas lo que hace
     * que el resultado no esté sincronizado y el jackpot sea un evento
     * genuinamente probabilístico, no garantizado. Si todas las ruedas
     * están fijas, la operación falla.
     */
    public void spin() {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas para girar.");
            return;
        }
        boolean anySpun = false;
        for (Wheel w : wheels) {
            if (w.isLocked()) {
                continue;
            }
            int symbolCount = w.colors().length;
            if (symbolCount == 0) {
                continue;
            }
            int steps = 1 + random.nextInt(symbolCount);
            for (int i = 0; i < steps; i++) {
                anySpun = w.spin() || anySpun;
            }
        }
        lastOperationOk = anySpun;
        if (!lastOperationOk) {
            handleError("Todas las ruedas están fijas o vacías; no giró ninguna.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Deja la máquina en la configuración de colores indicada, un color por
     * cada rueda, de izquierda a derecha. Cada color debe existir ya en la
     * rueda correspondiente (se ubica con {@code placeSymbol}, no se crea).
     *
     * @param setSymbols Colores deseados, uno por rueda, de izquierda a derecha
     */
    public void spin(String[] setSymbols) {
        if (wheels.isEmpty()) {
            handleError("No hay ruedas disponibles.");
            return;
        }
        if (setSymbols == null || setSymbols.length != wheels.size()) {
            handleError("La configuración debe tener exactamente un color por rueda.");
            return;
        }
        boolean allOk = true;
        for (int i = 0; i < wheels.size(); i++) {
            allOk = wheels.get(i).placeSymbol(setSymbols[i]) && allOk;
        }
        lastOperationOk = allOk;
        if (!lastOperationOk) {
            handleError("Alguno de los colores indicados no existe en su rueda.");
        } else {
            refreshDisplay();
        }
    }

    /**
     * Retorna los colores de los símbolos de la primera rueda, en el orden
     * en que están ubicados dentro de ella, iniciando por la posición 1.
     *
     * @return Nombres de los colores
     */
    public String[] symbols() {
        lastOperationOk = true;
        if (wheels.isEmpty()) {
            return new String[0];
        }
        return wheels.get(0).colors();
    }

    /**
     * Retorna el número de colores distintos entre los símbolos de la primera rueda.
     *
     * @return Cantidad de colores únicos
     */
    public int distinctSymbols() {
        String[] allSyms = symbols();
        Set<String> distinct = new HashSet<>();
        for (String color : allSyms) {
            distinct.add(color.toLowerCase());
        }
        lastOperationOk = true;
        return distinct.size();
    }

    /**
     * Retorna la combinación de colores actualmente visibles en todas las
     * ruedas de la máquina, ordenados de izquierda a derecha.
     *
     * @return Arreglo de colores visibles
     */
    public String[] configuration() {
        String[] config = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            config[i] = wheels.get(i).visibleColor();
        }
        lastOperationOk = true;
        return config;
    }

    /**
     * Indica si la configuración actual es ganadora, es decir, si todas las
     * ruedas muestran símbolos del mismo color.
     *
     * @return {@code true} si la configuración visible es ganadora
     */
    public boolean isJackpot() {
        if (wheels.isEmpty()) {
            return false;
        }
        String[] config = configuration();
        String first = config[0];
        if (first == null || first.isEmpty()) {
            return false;
        }
        for (String color : config) {
            if (!color.equalsIgnoreCase(first)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Hace visible la interfaz gráfica del simulador.
     */
    public void makeVisible() {
        this.isVisible = true;
        lastOperationOk = true;
        frame.makeVisible();
        base.makeVisible();
        leverArm.makeVisible();
        leverBall.makeVisible();
        refreshDisplay();
    }

    /**
     * Oculta la interfaz gráfica del simulador.
     */
    public void makeInvisible() {
        this.isVisible = false;
        lastOperationOk = true;
        for (Wheel w : wheels) {
            w.hide();
        }
        frame.makeInvisible();
        base.makeInvisible();
        leverArm.makeInvisible();
        leverBall.makeInvisible();
    }

    /**
     * Finaliza la sesión del simulador, ocultando la interfaz y liberando las
     * ruedas actuales.
     */
    public void exit() {
        makeInvisible();
        wheels.clear();
        lastOperationOk = true;
    }

    /**
     * Consulta si la última operación solicitada se ejecutó correctamente.
     *
     * @return {@code true} si la última operación fue exitosa
     */
    public boolean ok() {
        return lastOperationOk;
    }

    // ---------------------------------------------------------------------
    // Métodos privados
    // ---------------------------------------------------------------------

    /**
     * Construye los componentes visuales fijos de la máquina (marco, base y palanca).
     */
    private void initStructure() {
        this.frame = new Rectangle();
        this.frame.changeSize(160, 240);
        this.frame.moveHorizontal(30);
        this.frame.moveVertical(30);
        this.frame.changeColor("blue");

        this.base = new Rectangle();
        this.base.changeSize(20, 200);
        this.base.moveHorizontal(50);
        this.base.moveVertical(190);
        this.base.changeColor("black");

        this.leverArm = new Rectangle();
        this.leverArm.changeSize(60, 8);
        this.leverArm.moveHorizontal(270);
        this.leverArm.moveVertical(70);
        this.leverArm.changeColor("black");

        this.leverBall = new Circle();
        this.leverBall.changeSize(22);
        this.leverBall.moveHorizontal(263);
        this.leverBall.moveVertical(55);
        this.leverBall.changeColor("red");
    }

    /**
     * Configura el estado inicial por defecto: tres ruedas, cada una con un símbolo.
     */
    private void initDefaultConfiguration() {
        addWheel(1);
        addWheel(2);
        addWheel(3);

        addSymbol(1, "red");
        addSymbol(2, "blue");
        addSymbol(3, "yellow");
    }

    /**
     * Ajusta una posición de inserción (0..size) a los límites válidos de la lista.
     *
     * @param pos  Posición basada en 1 solicitada por el usuario
     * @param size Tamaño actual de la lista sobre la que se inserta
     * @return Índice de inserción basado en 0, dentro de [0, size]
     */
    private int clampInsertPosition(int pos, int size) {
        if (pos < 1) {
            return 0;
        }
        if (pos > size) {
            return size;
        }
        return pos - 1;
    }

    /**
     * Ajusta un número de rueda (basado en 1) a los límites válidos [1, wheels.size()].
     * Debe usarse únicamente cuando ya se verificó que existe al menos una rueda.
     *
     * @param wheel Número de rueda solicitado
     * @return Número de rueda ajustado, basado en 1
     */
    private int clampWheelNumber(int wheel) {
        if (wheel < 1) {
            return 1;
        }
        if (wheel > wheels.size()) {
            return wheels.size();
        }
        return wheel;
    }

    /**
     * Registra un error de la última operación y, si el simulador está visible,
     * lo notifica al usuario mediante un mensaje emergente.
     *
     * @param message Mensaje descriptivo del error
     */
    private void handleError(String message) {
        lastOperationOk = false;
        if (isVisible) {
            JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Pausa breve usada para animar paso a paso el giro de una rueda.
     */
    private void pause() {
        try {
            Thread.sleep(SPIN_STEP_DELAY_MS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Calcula la distribución horizontal de las ruedas y le pide a cada una
     * que se dibuje en su posición correspondiente. Cambia el color del
     * marco si la configuración visible es ganadora.
     */
    private void refreshDisplay() {
        if (!isVisible) {
            return;
        }
        frame.changeColor(isJackpot() && !wheels.isEmpty() ? "green" : "blue");

        int numWheels = wheels.size();
        if (numWheels == 0) {
            return;
        }

        int availableWidth = 200;
        int wheelWidth = Math.min(50, (availableWidth / numWheels) - 10);
        int totalWheelsWidth = numWheels * wheelWidth + (numWheels - 1) * 10;
        int startX = 30 + (240 - totalWheelsWidth) / 2;

        for (int i = 0; i < numWheels; i++) {
            int posX = startX + i * (wheelWidth + 10);
            wheels.get(i).display(posX, wheelWidth);
        }
    }
}