import java.util.ArrayList;
import java.util.List;

/**
 * Representa una rueda con una secuencia circular de símbolos. La rueda
 * mantiene un índice de la posición actualmente visible, es responsable de
 * mostrarse y ocultarse a sí misma, y oculta completamente el tipo
 * {@link Symbol} hacia el exterior: expone únicamente colores (String) y
 * resultados de operación (boolean).
 *
 * Desde el ciclo 2, la rueda también puede fijarse (lock) para impedir que
 * gire cuando se hace girar toda la máquina.
 *
 * @author GonzalezM-LesmesA
 * @version 1.5
 */
public class Wheel {

    /** Posición vertical fija de la ventana de la rueda dentro de la máquina. */
    private static final int WINDOW_Y = 55;
    /** Posición vertical fija del símbolo dentro de la ventana de la rueda. */
    private static final int SYMBOL_Y = 90;

    private List<Symbol> symbols;
    private int visibleIndex;
    private boolean locked;
    private Rectangle window;

    /**
     * Inicializa la rueda vacía, sin símbolos y libre (no fija).
     */
    public Wheel() {
        this.symbols = new ArrayList<>();
        this.visibleIndex = 0;
        this.locked = false;
    }

    /**
     * Agrega un símbolo con el color indicado en la posición dada, si el
     * color es un color CSS válido. Si la posición es menor a 1 se usa 1;
     * si es mayor al máximo posible se usa el máximo.
     *
     * @param pos   Posición dentro de la rueda, basada en 1
     * @param color Color del símbolo a agregar
     * @return {@code true} si el color era válido y el símbolo fue agregado
     */
    public boolean addSymbol(int pos, String color) {
        if (!Symbol.isValidColor(color)) {
            return false;
        }
        int index = adjustIndex(pos);
        symbols.add(index, new Symbol(color));
        return true;
    }

    /**
     * Agrega un símbolo con un color y una figura geométrica específicos, en
     * la posición dada, si el color es válido.
     *
     * @param pos       Posición dentro de la rueda, basada en 1
     * @param color     Color del símbolo a agregar
     * @param shapeType Figura geométrica asociada al símbolo
     * @return {@code true} si el color era válido y el símbolo fue agregado
     */
    public boolean addSymbol(int pos, String color, String shapeType) {
        if (!Symbol.isValidColor(color)) {
            return false;
        }
        int index = adjustIndex(pos);
        symbols.add(index, new Symbol(color, shapeType));
        return true;
    }

    /**
     * Elimina el primer símbolo cuyo color coincida con el indicado.
     *
     * @param color Color del símbolo a eliminar
     * @return {@code true} si se encontró y eliminó un símbolo con ese color
     */
    public boolean delSymbol(String color) {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equalsIgnoreCase(color)) {
                symbols.remove(i);
                adjustVisibleIndex();
                return true;
            }
        }
        return false;
    }

    /**
     * Ubica como visible el primer símbolo cuyo color coincida con el indicado.
     *
     * @param color Color del símbolo a ubicar
     * @return {@code true} si se encontró y ubicó un símbolo con ese color
     */
    public boolean placeSymbol(String color) {
        for (int i = 0; i < symbols.size(); i++) {
            if (symbols.get(i).getColor().equalsIgnoreCase(color)) {
                visibleIndex = i;
                return true;
            }
        }
        return false;
    }

    /**
     * Avanza un paso hacia adelante la posición visible de la rueda, de
     * forma circular. No hace nada si la rueda está fija o vacía.
     *
     * @return {@code true} si la rueda efectivamente giró
     */
    public boolean spin() {
        if (locked || symbols.isEmpty()) {
            return false;
        }
        visibleIndex = (visibleIndex + 1) % symbols.size();
        return true;
    }

    /**
     * Fija la rueda, impidiendo que gire hasta que se libere con {@link #unlock()}.
     *
     * @return {@code true} si la rueda no estaba ya fija
     */
    public boolean lock() {
        if (locked) {
            return false;
        }
        locked = true;
        return true;
    }

    /**
     * Libera la rueda previamente fijada.
     *
     * @return {@code true} si la rueda estaba fija
     */
    public boolean unlock() {
        if (!locked) {
            return false;
        }
        locked = false;
        return true;
    }

    /**
     * Consulta si la rueda está actualmente fija.
     *
     * @return {@code true} si la rueda está fija
     */
    public boolean isLocked() {
        return locked;
    }

    /**
     * Retorna los colores de los símbolos de la rueda, en el orden en que
     * están ubicados internamente, iniciando por la posición 1.
     *
     * @return Arreglo de colores de la rueda
     */
    public String[] colors() {
        String[] result = new String[symbols.size()];
        for (int i = 0; i < symbols.size(); i++) {
            result[i] = symbols.get(i).getColor();
        }
        return result;
    }

    /**
     * Retorna el color del símbolo actualmente visible en la rueda.
     *
     * @return Color visible, o cadena vacía si la rueda no tiene símbolos
     */
    public String visibleColor() {
        Symbol visible = currentSymbol();
        return (visible != null) ? visible.getColor() : "";
    }

    /**
     * Muestra la ventana de esta rueda y su símbolo visible, en la posición
     * horizontal y con el ancho indicados. Si ya estaba visible, se redibuja
     * en la nueva posición. La ventana se pinta de un color distinto cuando
     * la rueda está fija, como indicador visual del bloqueo.
     *
     * @param x     Posición horizontal de la rueda
     * @param width Ancho asignado a la rueda
     */
    public void display(int x, int width) {
        hide();
        window = new Rectangle();
        window.changeSize(110, width);
        window.changeColor(locked ? "gray" : "white");
        window.moveHorizontal(x);
        window.moveVertical(WINDOW_Y);
        window.makeVisible();

        Symbol visible = currentSymbol();
        if (visible != null) {
            int size = Math.max(8, width - 12);
            visible.display(x + 6, SYMBOL_Y, size);
        }
    }

    /**
     * Oculta la ventana de esta rueda y su símbolo visible.
     */
    public void hide() {
        if (window != null) {
            window.makeInvisible();
            window = null;
        }
        Symbol visible = currentSymbol();
        if (visible != null) {
            visible.hide();
        }
    }

    /**
     * Retorna el símbolo actualmente visible en la rueda. Es de uso interno
     * de la clase: {@link Symbol} nunca se expone fuera de {@code Wheel}.
     *
     * @return El símbolo visible, o {@code null} si la rueda está vacía
     */
    private Symbol currentSymbol() {
        if (symbols.isEmpty()) {
            return null;
        }
        return symbols.get(visibleIndex);
    }

    /**
     * Ajusta una posición de inserción (basada en 1) a un índice válido
     * dentro de la lista de símbolos (basado en 0, en el rango [0, size]).
     *
     * @param pos Posición basada en 1 solicitada por el usuario
     * @return Índice de inserción basado en 0
     */
    private int adjustIndex(int pos) {
        if (pos < 1) {
            return 0;
        }
        if (pos > symbols.size()) {
            return symbols.size();
        }
        return pos - 1;
    }

    /**
     * Corrige el índice visible si quedó fuera de rango tras eliminar un símbolo.
     */
    private void adjustVisibleIndex() {
        if (visibleIndex >= symbols.size() && !symbols.isEmpty()) {
            visibleIndex = 0;
        }
    }
}