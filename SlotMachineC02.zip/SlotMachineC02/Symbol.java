import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Representa un símbolo de la máquina tragamonedas, definido por su color
 * (según el estándar CSS) y la figura geométrica que lo representa
 * visualmente. El propio símbolo es responsable de mostrarse y ocultarse en
 * pantalla, y de saber si un color es válido.
 *
 * @author GonzalezM-LesmesA
 */
public class Symbol {

    /** Nombres de colores CSS reconocidos por el simulador. */
    private static final Set<String> VALID_COLORS = new HashSet<>(Arrays.asList(
            "black", "white", "red", "green", "blue", "yellow", "cyan", "magenta",
            "gray", "grey", "orange", "purple", "pink", "brown", "lime", "navy",
            "teal", "maroon", "olive", "silver", "gold", "indigo", "violet",
            "turquoise", "coral", "salmon", "khaki", "orchid", "crimson", "chocolate"
    ));

    private String color;
    private String shapeType;

    // Figura geométrica actualmente visible en pantalla (a lo sumo una a la vez)
    private Circle circleShape;
    private Rectangle rectShape;
    private Triangle triangleShape;

    /**
     * Crea un símbolo asociando automáticamente una figura a un color.
     *
     * @param color Color CSS del símbolo
     */
    public Symbol(String color) {
        this.color = color.toLowerCase();
        this.shapeType = assignShapeByColor(this.color);
    }

    /**
     * Crea un símbolo con un color y una figura específicos.
     *
     * @param color     Color CSS del símbolo
     * @param shapeType Figura geométrica asociada al símbolo
     */
    public Symbol(String color, String shapeType) {
        this.color = color.toLowerCase();
        this.shapeType = shapeType.toLowerCase();
    }

    /**
     * Indica si un nombre de color corresponde a un color CSS reconocido por el simulador.
     *
     * @param color Nombre de color a validar
     * @return {@code true} si el color es válido
     */
    public static boolean isValidColor(String color) {
        return color != null && VALID_COLORS.contains(color.toLowerCase());
    }

    /**
     * Retorna el color del símbolo.
     *
     * @return Nombre del color CSS
     */
    public String getColor() {
        return color;
    }

    /**
     * Retorna la figura geométrica asociada al símbolo.
     *
     * @return Nombre de la figura geométrica
     */
    public String getShapeType() {
        return shapeType;
    }

    /**
     * Muestra la figura geométrica de este símbolo en la posición y tamaño indicados.
     * Si ya estaba visible, se vuelve a dibujar en la nueva posición.
     *
     * @param x    Posición horizontal
     * @param y    Posición vertical
     * @param size Tamaño de la figura
     */
    public void display(int x, int y, int size) {
        hide();
        if ("rectangle".equals(shapeType) || "square".equals(shapeType)) {
            rectShape = new Rectangle();
            rectShape.changeSize(size, size);
            rectShape.changeColor(color);
            rectShape.moveHorizontal(x);
            rectShape.moveVertical(y);
            rectShape.makeVisible();
        } else if ("triangle".equals(shapeType)) {
            triangleShape = new Triangle();
            triangleShape.changeSize(size, size);
            triangleShape.changeColor(color);
            triangleShape.moveHorizontal(x + size / 2);
            triangleShape.moveVertical(y);
            triangleShape.makeVisible();
        } else {
            circleShape = new Circle();
            circleShape.changeSize(size);
            circleShape.changeColor(color);
            circleShape.moveHorizontal(x);
            circleShape.moveVertical(y);
            circleShape.makeVisible();
        }
    }

    /**
     * Oculta la figura geométrica de este símbolo, si está actualmente visible.
     */
    public void hide() {
        if (circleShape != null) {
            circleShape.makeInvisible();
            circleShape = null;
        }
        if (rectShape != null) {
            rectShape.makeInvisible();
            rectShape = null;
        }
        if (triangleShape != null) {
            triangleShape.makeInvisible();
            triangleShape = null;
        }
    }

    /**
     * Mapea un color a una figura geométrica por defecto para su representación visual.
     *
     * @param color Color CSS ya normalizado en minúsculas
     * @return Nombre de la figura geométrica asignada
     */
    private String assignShapeByColor(String color) {
        switch (color) {
            case "blue":
            case "cyan":
                return "rectangle";
            case "yellow":
            case "green":
                return "triangle";
            default:
                return "circle";
        }
    }
}